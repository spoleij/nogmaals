from RobotArm import RobotArm

robotArm = RobotArm('exercise 5')

# Jouw python instructies zet je vanaf hier:


# ER IS GEEN OEFENING 5 OP DE SITE?????


# Na jouw code wachten tot het sluiten van de window:
robotArm.wait()